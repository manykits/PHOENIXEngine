This file is used to ensure the full directory path is created when first 
creating the project.